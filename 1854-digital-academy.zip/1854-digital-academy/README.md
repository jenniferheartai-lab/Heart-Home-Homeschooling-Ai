# 1854 Digital Academy

A GitHub-ready static website inspired by 1854 American education with modern-friendly layout and an adaptive tutor hub.

## Folder Structure

```text
1854-digital-academy/
├── index.html
├── README.md
├── assets/
│   ├── css/
│   │   └── styles.css
│   ├── img/
│   └── js/
│       ├── components.js
│       ├── main.js
│       └── tutor.js
└── pages/
    ├── math.html
    ├── reading.html
    ├── tutor-hub.html
    └── writing.html
```

## GitHub Setup

1. Sign in to GitHub.
2. Click **New repository**.
3. Name it `1854-digital-academy`.
4. Choose **Public** or **Private**.
5. Click **Create repository**.
6. Upload all files from this folder.
7. Commit the files.
8. To publish with GitHub Pages, open **Settings > Pages**.
9. Under **Build and deployment**, choose **Deploy from a branch**.
10. Select the `main` branch and `/ (root)` folder.
11. Save. GitHub will publish the site and give you a live URL.

## Notes

- Shared nav and footer are injected by `components.js`.
- Tutor chat history and confusion tracking are stored in browser `localStorage`.
- The current tutor uses rule-based JavaScript logic and can later be connected to a real AI API.
