document.addEventListener('DOMContentLoaded', () => {
  document.querySelectorAll('textarea, input[type="text"]').forEach((field) => {
    const key = `academy-field-${field.id}`;
    const saved = localStorage.getItem(key);
    if (saved) field.value = saved;

    field.addEventListener('input', () => {
      localStorage.setItem(key, field.value);
    });
  });
});
