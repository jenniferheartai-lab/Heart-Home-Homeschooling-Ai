(function () {
  const inPagesFolder = window.location.pathname.includes('/pages/');
  const root = inPagesFolder ? '../' : './';

  const header = `
    <header class="sticky-nav">
      <div class="nav-inner">
        <a class="brand" href="${root}index.html">
          1854 Digital Academy
          <small>Vintage scholarship for modern learners</small>
        </a>
        <nav class="nav-links" aria-label="Main navigation">
          <a href="${root}index.html">Home</a>
          <a href="${root}pages/reading.html">Reading</a>
          <a href="${root}pages/math.html">Math</a>
          <a href="${root}pages/writing.html">Writing</a>
          <a href="${root}pages/tutor-hub.html">Tutor Hub</a>
        </nav>
      </div>
    </header>
  `;

  const footer = `
    <footer class="site-footer">
      <div class="footer-inner">
        <strong>1854 Digital Academy</strong>
        <p>Reading, arithmetic, writing, and a courteous schoolmaster for the modern age.</p>
        <p><a href="${root}pages/tutor-hub.html">Meet the Tutor</a> · <a href="${root}pages/reading.html">Reading</a> · <a href="${root}pages/math.html">Math</a> · <a href="${root}pages/writing.html">Writing</a></p>
      </div>
    </footer>
  `;

  const headerSlot = document.getElementById('site-header');
  const footerSlot = document.getElementById('site-footer');

  if (headerSlot) headerSlot.innerHTML = header;
  if (footerSlot) footerSlot.innerHTML = footer;

  const current = window.location.pathname.split('/').pop() || 'index.html';
  document.addEventListener('DOMContentLoaded', () => {
    document.querySelectorAll('.nav-links a').forEach((link) => {
      if (link.getAttribute('href').endsWith(current)) {
        link.classList.add('active');
      }
    });
  });
})();
