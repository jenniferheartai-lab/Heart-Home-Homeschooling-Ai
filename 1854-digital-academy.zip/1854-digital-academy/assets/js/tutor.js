const TutorApp = (() => {
  const storageKey = 'mr-hawthorne-chat-history';
  const confusionKey = 'mr-hawthorne-confusion-log';

  const styleModes = {
    standard: 'formal guidance',
    simple: 'simpler words',
    step: 'step-by-step explanation',
    example: 'real-life example'
  };

  const starterMessage = {
    role: 'bot',
    text: 'Pray tell, young scholar, what subject troubles thee today? I am prepared to explain reading, arithmetic, writing, or even the astonishing wonders of digital machinery.'
  };

  function getHistory() {
    try {
      return JSON.parse(localStorage.getItem(storageKey)) || [starterMessage];
    } catch {
      return [starterMessage];
    }
  }

  function saveHistory(history) {
    localStorage.setItem(storageKey, JSON.stringify(history));
  }

  function saveConfusion(item) {
    const current = JSON.parse(localStorage.getItem(confusionKey) || '[]');
    current.push({ ...item, timestamp: new Date().toISOString() });
    localStorage.setItem(confusionKey, JSON.stringify(current));
  }

  function render(history) {
    const chatLog = document.getElementById('chat-log');
    if (!chatLog) return;

    chatLog.innerHTML = '';
    history.forEach((entry) => {
      const div = document.createElement('div');
      div.className = `message ${entry.role}`;
      div.textContent = entry.text;
      chatLog.appendChild(div);
    });
    chatLog.scrollTop = chatLog.scrollHeight;
  }

  function detectIntent(message) {
    const lower = message.toLowerCase();
    if (/(don't understand|do not understand|confused|lost|huh|what do you mean)/.test(lower)) return 'confused';
    if (/(math|add|subtract|number|count|multiply|divide|bytes)/.test(lower)) return 'math';
    if (/(read|reading|phonics|book|story|literature)/.test(lower)) return 'reading';
    if (/(write|writing|diary|cursive|essay|composition)/.test(lower)) return 'writing';
    if (/(computer|internet|tablet|phone|smartphone|digital)/.test(lower)) return 'modern';
    return 'general';
  }

  function buildReply(message, history) {
    const intent = detectIntent(message);
    const lastUserMessage = [...history].reverse().find((item) => item.role === 'user')?.text || message;

    if (intent === 'confused') {
      saveConfusion({ query: lastUserMessage });
      const adaptiveReplies = [
        `I understand. Let us try again with ${styleModes.simple}. We shall use fewer grand words and speak plainly. Tell me which part puzzled thee most.`,
        `Very good for saying so. Let us go by ${styleModes.step}: first the beginning, then the middle, then the end. We shall not gallop when a steady walk will do.`,
        `No shame in confusion, young scholar. Let me offer a ${styleModes.example}. Think of the lesson as a basket: we place one idea in at a time.`
      ];
      return adaptiveReplies[Math.floor(Math.random() * adaptiveReplies.length)];
    }

    if (intent === 'math') {
      return 'Capital! In arithmetic, we look first to what is given, next to what changes, and lastly to what remains. If thou tellest me the numbers, I shall help thee reckon them neatly.';
    }

    if (intent === 'reading') {
      return 'Behold, reading is the art of hearing meaning within words. We may inspect the sentence, note the tone, and gather clues from curious phrases. Share the passage, and we shall examine it together.';
    }

    if (intent === 'writing') {
      return 'Excellent work, young scholar. Good writing requires clear thought, graceful order, and strong expression. First decide what happened, then what thou felt, and then how best to say it with dignity.';
    }

    if (intent === 'modern') {
      return 'Pray tell, these modern devices are marvels indeed. A smartphone is as though a telegraph office, library, map drawer, and portrait studio were all tucked into one’s pocket. Ask, and I shall explain the wonder plainly.';
    }

    return 'Pray continue, and I shall do my utmost to assist thee. Whether thy trouble be reading, numbers, or composition, we shall tackle it with patience and a cheerful spirit.';
  }

  function init() {
    const form = document.getElementById('chat-form');
    const input = document.getElementById('user-message');
    const clearBtn = document.getElementById('clear-chat');
    if (!form || !input) return;

    let history = getHistory();
    render(history);

    form.addEventListener('submit', (event) => {
      event.preventDefault();
      const text = input.value.trim();
      if (!text) return;

      history.push({ role: 'user', text });
      const reply = buildReply(text, history);
      history.push({ role: 'bot', text: reply });

      saveHistory(history);
      render(history);
      input.value = '';
    });

    clearBtn?.addEventListener('click', () => {
      history = [starterMessage];
      localStorage.removeItem(storageKey);
      render(history);
    });
  }

  return { init };
})();

document.addEventListener('DOMContentLoaded', TutorApp.init);
